<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UFT-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?php bloginfo ('stylesheet_url');?>">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Do+Hyeon" rel="stylesheet">
    <title>hogehoge</title>
  </head>
  <body>
    <div class="home wrap"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <h1 class="title">hogeHogeBlog</h1>
        <h2 class="subTitle">classActionDeveloperBlog</h2></a></div>
  </body>
</html>
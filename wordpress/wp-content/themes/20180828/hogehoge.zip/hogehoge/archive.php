<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="./style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Do+Hyeon" rel="stylesheet">
    <title>hogehoge</title>
  </head>
  <body>
    <div class="home wrap">
      <h1 class="title">hogeHogeBlog</h1>
      <h2 class="subTitle">classActionDeveloperBlog</h2>
    </div>
    <div class="wrap outline">
      <ul class="blogListArea">
        <li class="blogList"><a href="https://enjin-classaction.com/">
            <div class="blogListTitle">テストコンテンツテストコンテンツ</div>
            <div class="blogListDate">2018.08.22</div>
            <div class="blogListContents">テストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらから</div></a></li>
        <li class="blogList"><a href="https://enjin-classaction.com/">
            <div class="blogListTitle">テストコンテンツテストコンテンツ</div>
            <div class="blogListDate">2018.08.22</div>
            <div class="blogListContents">テストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらからテストコンテンツはこちらから</div></a></li>
      </ul>
    </div>
  </body>
</html>